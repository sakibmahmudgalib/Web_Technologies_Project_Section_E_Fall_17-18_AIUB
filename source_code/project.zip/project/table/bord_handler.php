 <?php
	if(empty($_REQUEST['auname'])==false and empty($_REQUEST['apassword'])==false)
	{
		//$auname= $_REQUEST['auname'];
		//$password= $_REQUEST['apassword'];
		//echo "Name : ".$auname."<br/>";
		//echo "Password : ".$password."<br/>";
		//include 'bord.html';
		
	}
	else
	{
		//include 'name.html';
		echo  "Enter valid info"."<br/>";
	
	}
	
?>